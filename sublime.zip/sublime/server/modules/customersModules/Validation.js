const joi = require('@hapi/joi')

const validateCustomer  = async (req,res,next) => {
    try {
        console.log(req.body);
        console.log(req.file);
        const customerSchema = joi.object({
            first_name : joi.string().required(),
            last_name  : joi.string().required(),
            city     : joi.string().valid('ahmedabad','pune',"rajkot").required(),
            company  : joi.string().valid('sublime','TCS',"Facebook").required()
        })
        await customerSchema.validateAsync(req.body)
        console.log('it is validated')
        next()  
    } catch(error) {
        console.log(error);
        // resHndlr.validationErrorHandler(res, error);
    }
}

module.exports = {
    validateCustomer
}