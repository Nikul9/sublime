const MESSAGE = {

    // emailExist: 'Coustomer already exist.',
    addSuccess: 'Coustomer add successfully',
    addError: 'There is some issue with add Coustomers',

    getSuccess: 'Data get successfully.',
    getError: 'There is some with get data.'
}

module.exports = {
    MESSAGE
}