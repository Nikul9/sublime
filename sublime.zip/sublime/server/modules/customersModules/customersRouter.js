const express = require("express")
const router = new express.Router()
const fcade = require('./customersFcade')
const resHendler = require('../../handlers/responseHandler')
const multer = require('multer')
const { validateCustomer } = require("./Validation")
const storage = multer.diskStorage({
    destination: 'public/image',
   
    filename : function (req, file , cb) {
       // console.log(file.originalname);
        cb(null , file.originalname);
    },
    fileFilter(req, file, cb) {
        if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
            return cb(new Error('Please upload an image'))
        }
        cb(undefined, true)
    }
})
const upload = multer({storage})

// Create an API to add a customer with validations.
// upload.single("image")
router.route('/addCustomer').post(validateCustomer,(req,res) => {
    console.log(req.body);
    fcade.addCustomer(req,res).then((result) => {
        console.log(result);
        return resHendler.successHandler(res,result)
    }).catch((e) => {
        return resHendler.errorHandler(res, e)
    })
})

//  Create a list API with search by first_name, last_name and city with pagination.

router.route(`/serch`).get((req,res) => {
    fcade.serch(req,res).then((result) => {
        return resHendler.successHandler(res,result)
    }).catch((e) => {
        return resHendler.errorHandler(res, e)
    })
})

//  Create an API to list all the unique cities with number of customers from a particular city

router.route(`/findCityWithCustomer`).get((req,res) => {
    fcade.findCityWithCustomer(req,res).then((result) => {
        return resHendler.successHandler(res,result)
    }).catch((e) => {
        return resHendler.errorHandler(res, e)
    })
})

// Create an API to get single customer data by its id.

router.route('/oneUser').get((req,res) => {
    fcade.oneUser(req,res).then((result) => {
        return resHendler.successHandler(res,result)
    }).catch((e) => {
        return resHendler.errorHandler(res, e)
    })
})

router.route('/allCustomer').get((req,res) => {
    console.log("NIKUL");
    fcade.allCustomer(req,res).then((result) => {
        return resHendler.successHandler(res,result)
    }).catch((e) => {
        return resHendler.errorHandler(res, e)
    })
})

// upload.single('image')

router.route('/editUser').patch((req,res) => {
    fcade.editUser(req,res).then((result) => {
        return resHendler.successHandler(res,result)
    }).catch((e) => {
        return resHendler.errorHandler(res, e)
    })
})

module.exports = router
